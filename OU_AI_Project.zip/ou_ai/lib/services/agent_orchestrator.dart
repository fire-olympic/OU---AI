import 'dart:convert';
import 'package:http/http.dart' as http;

class AIProvider {
  final String name;
  final String apiEndpoint;
  bool isHealthy;

  AIProvider({
    required this.name,
    required this.apiEndpoint,
    this.isHealthy = true,
  });
}

class AgentOrchestrator {
  final String geminiKey;
  final String hfToken;
  final String groqKey;

  final List<AIProvider> _providers = [
    AIProvider(name: "Google Gemini 2.0 Flash", apiEndpoint: "https://generativelanguage.googleapis.com"),
    AIProvider(name: "Groq Llama 3.3 70B", apiEndpoint: "https://api.groq.com/openai/v1"),
    AIProvider(name: "Hugging Face Inference", apiEndpoint: "https://api-inference.huggingface.co"),
    AIProvider(name: "OpenRouter Free Mix", apiEndpoint: "https://openrouter.ai/api/v1"),
  ];

  int _currentProviderIndex = 0;

  AgentOrchestrator({
    required this.geminiKey,
    required this.hfToken,
    this.groqKey = '',
  });

  String get activeProviderName => _providers[_currentProviderIndex].name;

  void rotateToNextProvider() {
    _providers[_currentProviderIndex].isHealthy = false;
    _currentProviderIndex = (_currentProviderIndex + 1) % _providers.length;
  }

  Future<String> scrapeToolEndpoint(String url) async {
    try {
      final uri = Uri.parse(url);
      final response = await http.get(uri).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        String body = response.body;
        body = body.replaceAll(RegExp(r'<script[^>]*>([\s\S]*?)</script>'), '');
        body = body.replaceAll(RegExp(r'<style[^>]*>([\s\S]*?)</style>'), '');
        body = body.replaceAll(RegExp(r'<[^>]*>'), ' ');
        body = body.replaceAll(RegExp(r'\s+'), ' ');

        return body.length > 3000 ? body.substring(0, 3000) : body;
      }
      return "Endpoint returned status code: ${response.statusCode}";
    } catch (e) {
      return "Scrape notice: $e";
    }
  }

  Future<Map<String, dynamic>> executeOrchestratedWorkflow({
    required String prompt,
    required List<String> toolUrls,
  }) async {
    StringBuffer log = StringBuffer();
    log.writeln("⚙️ **O'U AI Agent Orchestrator Triggered**");

    List<String> scrapedToolDocs = [];

    for (var url in toolUrls) {
      log.writeln("🔌 Querying external agent endpoint: `$url`...");
      final toolDoc = await scrapeToolEndpoint(url);
      scrapedToolDocs.add("Tool ($url): $toolDoc");
    }

    log.writeln("🧠 Synthesizing workflow plan across active engines...");

    return {
      "log": log.toString(),
      "toolDocs": scrapedToolDocs,
    };
  }
}
