import 'dart:math';

class DocumentChunk {
  final String sourceFile;
  final String text;
  final Map<String, double> tfIdfVector;

  DocumentChunk({
    required this.sourceFile,
    required this.text,
    required this.tfIdfVector,
  });
}

class OfflineRAGEngine {
  final List<DocumentChunk> _index = [];

  void indexDocument(String fileName, String fullText) {
    if (fullText.trim().isEmpty) return;
    _index.removeWhere((chunk) => chunk.sourceFile == fileName);

    final rawParagraphs = fullText.split(RegExp(r'\n\s*\n|\r\n\r\n'));
    List<String> chunks = [];

    for (var para in rawParagraphs) {
      if (para.length > 600) {
        for (var i = 0; i < para.length; i += 500) {
          final end = (i + 500 < para.length) ? i + 500 : para.length;
          chunks.add(para.substring(i, end));
        }
      } else if (para.trim().isNotEmpty) {
        chunks.add(para.trim());
      }
    }

    for (var chunkText in chunks) {
      final terms = _tokenize(chunkText);
      final tfMap = <String, double>{};
      for (var term in terms) {
        tfMap[term] = (tfMap[term] ?? 0) + 1.0;
      }
      final totalTerms = terms.length.toDouble();
      if (totalTerms > 0) {
        tfMap.updateAll((key, value) => value / totalTerms);
      }
      _index.add(DocumentChunk(
        sourceFile: fileName,
        text: chunkText,
        tfIdfVector: tfMap,
      ));
    }
  }

  List<DocumentChunk> search(String query, {int topK = 3}) {
    if (_index.isEmpty || query.trim().isEmpty) return [];

    final queryTerms = _tokenize(query);
    final queryVector = <String, double>{};
    for (var term in queryTerms) {
      queryVector[term] = (queryVector[term] ?? 0) + 1.0;
    }

    List<MapEntry<DocumentChunk, double>> scoredChunks = [];

    for (var chunk in _index) {
      double score = _cosineSimilarity(queryVector, chunk.tfIdfVector);
      if (score > 0.0) {
        scoredChunks.add(MapEntry(chunk, score));
      }
    }

    scoredChunks.sort((a, b) => b.value.compareTo(a.value));
    return scoredChunks.take(topK).map((e) => e.key).toList();
  }

  List<String> _tokenize(String text) {
    return text
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9\s]'), ' ')
        .split(RegExp(r'\s+'))
        .where((t) => t.length > 2)
        .toList();
  }

  double _cosineSimilarity(Map<String, double> v1, Map<String, double> v2) {
    double dotProduct = 0.0;
    double normA = 0.0;
    double normB = 0.0;

    v1.forEach((key, val) {
      dotProduct += val * (v2[key] ?? 0.0);
      normA += val * val;
    });

    v2.forEach((key, val) {
      normB += val * val;
    });

    if (normA == 0.0 || normB == 0.0) return 0.0;
    return dotProduct / (sqrt(normA) * sqrt(normB));
  }

  void clearIndex() {
    _index.clear();
  }
}
