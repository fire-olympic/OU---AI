import 'dart:io';
import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';

class FaceSwapPipeline {
  final String huggingFaceToken;

  FaceSwapPipeline({required this.huggingFaceToken});

  Future<String?> executeFaceSwap({
    required String targetImagePath,
    required String sourceFacePath,
  }) async {
    try {
      final targetBytes = await File(targetImagePath).readAsBytes();
      final sourceBytes = await File(sourceFacePath).readAsBytes();

      final targetBase64 = base64Encode(targetBytes);
      final sourceBase64 = base64Encode(sourceBytes);

      final response = await http.post(
        Uri.parse('https://api-inference.huggingface.co/models/tonyassi/face-swap'),
        headers: {
          'Authorization': 'Bearer $huggingFaceToken',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'inputs': {
            'target_image': 'data:image/jpeg;base64,$targetBase64',
            'swap_image': 'data:image/jpeg;base64,$sourceBase64',
          }
        }),
      );

      if (response.statusCode == 200) {
        return await _saveResult(response.bodyBytes, 'ou_ai_faceswap');
      } else {
        return await _localImageBlendFallback(targetImagePath, sourceFacePath);
      }
    } catch (e) {
      return await _localImageBlendFallback(targetImagePath, sourceFacePath);
    }
  }

  Future<String?> _localImageBlendFallback(String imgPath1, String imgPath2) async {
    try {
      final bytes1 = await File(imgPath1).readAsBytes();
      final bytes2 = await File(imgPath2).readAsBytes();

      img.Image? baseImg = img.decodeImage(bytes1);
      img.Image? overlayImg = img.decodeImage(bytes2);

      if (baseImg == null || overlayImg == null) return null;

      img.Image resizedOverlay = img.copyResize(overlayImg, width: (baseImg.width * 0.4).round());

      img.compositeImage(
        baseImg,
        resizedOverlay,
        dstX: baseImg.width - resizedOverlay.width - 20,
        dstY: 20,
      );

      final resultBytes = Uint8List.fromList(img.encodePng(baseImg));
      return await _saveResult(resultBytes, 'ou_ai_composite_preview');
    } catch (e) {
      return null;
    }
  }

  Future<String> _saveResult(Uint8List bytes, String prefix) async {
    Directory directory;
    if (Platform.isAndroid) {
      directory = Directory('/storage/emulated/0/Download/OU_AI');
      if (!await directory.exists()) await directory.create(recursive: true);
    } else {
      directory = await getApplicationDocumentsDirectory();
    }

    final path = '${directory.path}/${prefix}_${DateTime.now().millisecondsSinceEpoch}.png';
    await File(path).writeAsBytes(bytes);
    return path;
  }
}
