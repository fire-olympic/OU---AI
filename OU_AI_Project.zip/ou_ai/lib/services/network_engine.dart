import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';

class NetworkEngine {
  final Connectivity _connectivity = Connectivity();
  StreamSubscription<List<ConnectivityResult>>? _subscription;

  bool _isOnline = true;
  bool get isOnline => _isOnline;

  void initialize(Function(bool isOnline) onStatusChanged) {
    _subscription = _connectivity.onConnectivityChanged.listen((results) {
      bool online = results.any((r) => r != ConnectivityResult.none);
      _isOnline = online;
      onStatusChanged(online);
    });
  }

  Future<bool> checkCurrentStatus() async {
    final results = await _connectivity.checkConnectivity();
    _isOnline = results.any((r) => r != ConnectivityResult.none);
    return _isOnline;
  }

  void dispose() {
    _subscription?.cancel();
  }
}
