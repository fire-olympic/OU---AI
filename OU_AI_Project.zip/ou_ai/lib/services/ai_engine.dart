import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:http/http.dart' as http;
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:path_provider/path_provider.dart';

import 'offline_rag.dart';
import 'image_pipeline.dart';

class AIEngineService {
  final String geminiApiKey;
  final String huggingFaceToken;
  final OfflineRAGEngine offlineRAG = OfflineRAGEngine();
  late FaceSwapPipeline faceSwapPipeline;

  AIEngineService({
    required this.geminiApiKey,
    this.huggingFaceToken = '',
  }) {
    faceSwapPipeline = FaceSwapPipeline(huggingFaceToken: huggingFaceToken);
  }

  Future<String> sendChatMessage({
    required String userPrompt,
    required List<String> knowledgeContext,
    required List<String> toolLinks,
    required bool forceOffline,
    required bool isNetworkConnected,
  }) async {
    final bool useOffline = forceOffline || !isNetworkConnected;

    if (useOffline) {
      return _generateOfflineResponse(userPrompt);
    }

    if (geminiApiKey.isEmpty) {
      return "⚠️ **API Key Missing**: Add your free Google Gemini API key in **O'U Engine** settings to activate online AI generation.\n\n_Switched to local engine mode._";
    }

    try {
      final model = GenerativeModel(
        model: 'gemini-1.5-flash',
        apiKey: geminiApiKey,
        systemInstruction: Content.system(
          "You are O'U AI, a universal AI agent assistant. "
          "You EXECUTE tasks, generate code, process media, and answer using uploaded knowledge. "
          "Always provide clean, action-oriented responses with markdown formatting."
        ),
      );

      String fullPrompt = userPrompt;

      if (knowledgeContext.isNotEmpty) {
        fullPrompt = """
=== KNOWLEDGE BASE CONTEXT ===
\${knowledgeContext.join('\n\n---\n\n')}

=== CONNECTED TOOLS ===
\${toolLinks.join('\n')}

=== USER PROMPT ===
\$userPrompt
""";
      }

      final response = await model.generateContent([Content.text(fullPrompt)]);
      return response.text ?? "O'U AI completed processing.";
    } catch (e) {
      return "🔴 Online API Notice: \${e.toString()}\n\n*Falling back to local offline search...*\n\n\${_generateOfflineResponse(userPrompt)}";
    }
  }

  String _generateOfflineResponse(String query) {
    final relevantChunks = offlineRAG.search(query, topK: 3);

    StringBuffer sb = StringBuffer();
    sb.writeln("📴 **O'U AI Local Engine (Offline Mode)**\n");

    if (relevantChunks.isNotEmpty) {
      sb.writeln("📚 **Matches from your Local Knowledge Base:**\n");
      for (var chunk in relevantChunks) {
        sb.writeln("> 📄 *\${chunk.sourceFile}*");
        sb.writeln("\${chunk.text}\n");
      }
    } else {
      sb.writeln("I am currently in **Offline Mode**. Connection to cloud models is unavailable.");
      sb.writeln("\n💡 *Tip: Upload PDFs or text docs in O'U Engine settings to query them completely offline.*");
    }

    return sb.toString();
  }

  Future<String?> executeFaceSwap(String targetImagePath, String sourceFacePath) async {
    return await faceSwapPipeline.executeFaceSwap(
      targetImagePath: targetImagePath,
      sourceFacePath: sourceFacePath,
    );
  }

  Future<String> extractAndIndexPDF(String filePath, String fileName) async {
    try {
      final File file = File(filePath);
      final Uint8List bytes = await file.readAsBytes();
      final PdfDocument document = PdfDocument(inputBytes: bytes);
      String text = PdfTextExtractor(document).extractText();
      document.dispose();

      offlineRAG.indexDocument(fileName, text);
      return text.length > 8000 ? text.substring(0, 8000) : text;
    } catch (e) {
      return "Extraction error: $e";
    }
  }

  Future<String> readAndIndexTextFile(String filePath, String fileName) async {
    try {
      final File file = File(filePath);
      String content = await file.readAsString();

      offlineRAG.indexDocument(fileName, content);
      return content.length > 8000 ? content.substring(0, 8000) : content;
    } catch (e) {
      return "Read error: $e";
    }
  }

  Future<String> analyzeImage(String imagePath, String prompt) async {
    if (geminiApiKey.isEmpty) return "⚠️ Gemini API key required for Vision tasks.";

    try {
      final model = GenerativeModel(model: 'gemini-1.5-flash', apiKey: geminiApiKey);
      final imageBytes = await File(imagePath).readAsBytes();
      final response = await model.generateContent([
        Content.multi([TextPart(prompt), DataPart('image/jpeg', imageBytes)])
      ]);
      return response.text ?? "Image analysis completed.";
    } catch (e) {
      return "🔴 Vision analysis error: $e";
    }
  }

  Future<String?> removeBackground(String imagePath) async {
    try {
      final imageBytes = await File(imagePath).readAsBytes();
      final response = await http.post(
        Uri.parse('https://api-inference.huggingface.co/models/briaai/RMBG-1.4'),
        headers: {
          'Authorization': 'Bearer $huggingFaceToken',
          'Content-Type': 'application/octet-stream',
        },
        body: imageBytes,
      );

      if (response.statusCode == 200) {
        return await _saveToDownloads(
          response.bodyBytes,
          'ou_ai_bg_removed_\${DateTime.now().millisecondsSinceEpoch}.png',
        );
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  Future<String?> saveCodeAsFile(String code, String filename) async {
    try {
      final directory = await _getDownloadsDirectory();
      final filePath = '\${directory.path}/$filename';
      final file = File(filePath);
      await file.writeAsString(code);
      return filePath;
    } catch (e) {
      return null;
    }
  }

  Future<Directory> _getDownloadsDirectory() async {
    if (Platform.isAndroid) {
      final directory = Directory('/storage/emulated/0/Download/OU_AI');
      if (!await directory.exists()) await directory.create(recursive: true);
      return directory;
    }
    return await getApplicationDocumentsDirectory();
  }

  Future<String> _saveToDownloads(Uint8List bytes, String filename) async {
    final directory = await _getDownloadsDirectory();
    final path = '\${directory.path}/$filename';
    await File(path).writeAsBytes(bytes);
    return path;
  }
}
